#include<iostream>
using namespace std;
int main()
{
	cout<<"0+传感器编号(1，2，3，4，5）0300010002"<<endl;
	cout<<"010300010002"<<endl;
	cout<<"应变: 3466.510010"<<endl;
	cout<<"温度: 25.399999"<<endl;
	cout<<"0+传感器编号（1，2，3，4，5）0300010002"<<endl;
	cout<<"020300010002"<<endl;
	cout<<"应变: 3312.379883"<<endl;
	cout<<"温度: 25.250010"<<endl;
	cout<<"0+传感器编号（1，2，3，4，5）0300010002"<<endl;
	
	
	
	return 0;
}





